<li class="<?php print $tab_classes?>">
<?php print $tab->content;?>
<?php print $tab_content; ?>
</li>