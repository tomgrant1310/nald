﻿/*
 Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'media', 'en', {
  alt: 'Alternative Text',	// Inherit from image plugin.
  captioned: 'Captioned image', // NEW property.
  lockRatio: 'Lock Ratio',	// Inherit from image plugin.
  menu: 'Image Properties',	// Inherit from image plugin.
  resetSize: 'Reset Size', // Inherit from image plugin.
  resizer: 'Click and drag to resize',	// NEW property.
  title: 'Image Properties',	// Inherit from image plugin.
  urlMissing: 'Image source URL is missing.' // Inherit from image plugin.
} );
